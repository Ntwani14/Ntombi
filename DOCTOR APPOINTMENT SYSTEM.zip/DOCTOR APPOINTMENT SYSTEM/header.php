<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Medical Management System</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<!--<link rel="stylesheet" href="style.css">-->
	<style>
		.error {color: #FF0000;}
	</style>
</head>
<body>
	<div class="container-fluid">
		<div class="header_top">
			<!-- <a href="index.php"><img src="img/dash2.jpg" alt="logo.png img"></a> -->

			<span style="font-size:50px;color:#2c2f84;font-weight:bolder;margin-left:15px;"
			 >Welcome To Doctor Appoinment System</span>
		</div>

	<!-- 	this is for menu -->
	<div class="jumbotron" style="background:url('img/3.jpg') no-repeat;background-size:cover;height:200px;"></div>
<div class="container-fluid">
<div class="row">
    <div class="col-md-2">
	<a href="index.php" class="list-group-item active">Home</a>
    </div>
	<div class="col-md-2">
	<a href="doctorinfo.php" class="list-group-item active">Doctor</a>
    </div>
	<div class="col-md-2">
	<a href="contactus.php" class="list-group-item active">Contact Us</a>
    </div>
	<div class="col-md-2">
	<a href="signin.php" class="list-group-item active">User Login</a>
    </div>
    <div class="col-md-1"></div>
</div>
</div>

	<!-- -->

	
