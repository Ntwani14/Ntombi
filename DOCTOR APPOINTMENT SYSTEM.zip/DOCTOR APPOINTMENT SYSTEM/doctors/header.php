<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>mms-doctors</title>
	<link rel="stylesheet" href="../patient/css/bootstrap.min.css">
	<div class="jumbotron" style="background:url('img/3.jpg') no-repeat;background-size:cover;height:200px;"></div>
	<style>
		.error {color: #FF0000;}
	</style>
</head>

<body>


<?php
		if($_SESSION['adminstatus'] == ""){
			header("location:doctorlogin.php");
		}
		
		   

	 ?>


<div class="container-fluid">
		<div class="header_top">
			
			<span style="font-size:50px;color:#2c2f84;font-weight:bolder;margin-left:15px;">Doctor Appoinment System</span>
		</div>

	<!-- 	this is for menu -->
	<div class="container-fluid">
<div class="row">
    <div class="col-md-2">
	<a href="myAppoinment.php" class="list-group-item active">My Appoinment</a>
    </div>
	<div class="col-md-2">
	<a href="myCustomer.php" class="list-group-item active">Customer Details</a>
    </div>
	<div class="col-md-2">
	<a href="myDetails.php" class="list-group-item active">My Details</a>
    </div>
	<div class="col-md-2">
	<a href="../patient/logout.php" class="list-group-item active">Logout</a>
    </div>
    <div class="col-md-1"></div>
</div>
</div>

	
