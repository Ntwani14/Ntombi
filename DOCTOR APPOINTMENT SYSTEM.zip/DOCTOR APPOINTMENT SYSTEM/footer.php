   <!-- footer section --> 
			<footer>
				<div class="col-md-12 fsection">
				
					<div class="col-md-4">
						<p>Contact</p> <hr>
						<p>Dr Mathebula <br>
							ntwano14@gmail.com <br>
							Cell: 0826874126</p>
							<li><a href="admin/adminlogin.php">Login as admin</a></li>
							
					</div>
					<div class="col-md-4 share_img">
					<p>Link With</p> <hr>
						<a href="" ><img src="img/fb-free.png" alt="facebok"></a>
						<a href=""><img src="img/gogle-plud-free.png" alt="google-plus"></a>
						<a href=""><img src="img/twitter.png" alt="twitter"></a>
						<div><span style="color: red;font-size: 15px">&copy;<?php echo date('Y'); ?>-All Rights Reserved</span></div>
						
					</div>
				</div>
				

			</footer>

		<!-- footer section Ends--> 
