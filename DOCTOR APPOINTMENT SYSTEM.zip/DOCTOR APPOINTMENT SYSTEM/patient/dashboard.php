<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>mms-patient</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<div class="jumbotron" style="background:url('img/header_img44.jpg') no-repeat;background-size:cover;height:200px;"></div>

</head>
<body>

<?php

// if($_SESSION['donorstatus']==""){
// 	header("location:../userlogin.php");
// }

?>
	<?php include('uptomenu.php'); ?>






	<!-- this is for donor registraton -->
	<div class="dashboard" style="background-color:#fff;">
		<h3 class="text-center" style="background-color:#272327;color: #fff;padding: 5px;">Welcome to Patient Portal</h3>
		
		
			
		
	</div>
	<br><br><br><br><br><br><br><br><br><b><b><br><br><br><br><br><b><b><br><br>
	



	
</div><!--  containerFluid Ends -->

<script src="js/bootstrap.min.js"></script>


</body>
</html>
