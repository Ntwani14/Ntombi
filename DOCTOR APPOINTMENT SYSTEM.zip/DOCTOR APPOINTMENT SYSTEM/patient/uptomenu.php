<div class="container-fluid">
		<div class="header_top">
			
			<span style="font-size:50px;color:#2c2f84;font-weight:bolder;margin-left:15px;">Doctor Appoinment System</span>
		</div>
		


	<!-- 	this is for menu -->
	<div class="container-fluid">
<div class="row">
<div class="col-md-2">
	<a href="myDetails.php" class="list-group-item active">My Details</a>
    </div>
<div class="col-md-2">
	<a href="search_doctor.php" class="list-group-item active">Search Doctors</a>
    </div>
    <div class="col-md-2">
	<a href="view_booking.php" class="list-group-item active">View Appoinment</a>
    </div>
	<div class="col-md-2">
	<a href="changepwd.php" class="list-group-item active">Change Password</a>
    </div>
	<div class="col-md-2">
	<a href="feedback.php" class="list-group-item active">Feedback</a>
    </div>
	<div class="col-md-2">
	<a href="logout.php" class="list-group-item active">Log Out</a>
    </div>
    <div class="col-md-1"></div>
</div>
</div>
