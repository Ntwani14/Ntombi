<?php include('header.php'); ?>

	<!-- this is for welcome -->

	<div class="col-md-3">
     <div class="jumbotron" style="background:url('img/gfgf.jpg') no-repeat;background-size:cover;height:220px;width:220px;"></div>
      </div>

	<div class="content">
	</div><br>

	<!-- nivo slider starts -->
	<!-- <div class="col-md-12 sliderImg">-->
		<!-- <img src="img/doctor1.jpg" alt="">-->

	</div>
	<!-- nivo slider ends -->

	<!-- main Content -->
	<div class="main_content">
		<div class="col-md-8">
			<article>
			
			</article>
		</div>
		<div class="col-md-4">
			
			
		</div>

          
    </div>

 	<?php include('footer.php'); ?>


	
</div>	<!--  containerFluid Ends -->



	<script src="js/jquery-1.9.0.min.js"></script>
	<script src="js/bootstrap.min.js"></script>

	 
	
</body>
</html>