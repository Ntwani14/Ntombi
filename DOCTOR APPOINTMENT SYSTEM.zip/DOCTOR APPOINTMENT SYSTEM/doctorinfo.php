<?php include('header.php'); ?>


	<!-- mc info -->
	<div class="doctors">
        
		                    <h3 class="text-center" style="background-color:#272327;color: #fff;">Doctor information</h3>
                            <div class="col-md-12" style="">
                                  


                                  <div class="col-md-3">
                                  <div class="jumbotron" style="background:url('img/hhh.jpg') no-repeat;background-size:cover;height:400px;"></div>
                                  </div> <br>

                                  <div class="col-md-3" > 

                                     
                                     <h3 style="color:#0616BC;">Dr. Ntwanano Mathebula</h3>


                                        <!-- Accordian Starts -->
                                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                                      Qualifications
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                                  <div class="panel-body">
                                                        medicine
                                                  </div>
                                                </div>
                                              </div>
                          
                                              </div>
                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingThree">
                                                  <h4 class="panel-title">
                                                    <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                                      Call for Appoinment 
                                                    </a>
                                                  </h4>
                                                </div>
                                                <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                                  <div class="panel-body">
                                                     Phone:+27826874126
                                                  </div>
                                                </div>
                                              </div>

                                              <div class="panel panel-default">
                                                <div class="panel-heading" role="tab" id="headingOne">
                                                  <h4 class="panel-title">
                                                    <a href="patient_login.php">
                                                      Get Appoinment
                                                    </a>
                                                  </h4>
                                                </div>
                                                
                                              </div>

                                            </div>
                                            <!-- Accordian End -->
                                            <!-- Accordian End -->
                                          <!-- Accordian End -->  
                                   </div> 
                             </div> <!-- col-md-12 End-->
                            <br><br>



	</div> <!-- Doctors End -->

    <!-- footer section --> 
			 <?php include('footer.php'); ?>
    <!-- footer section Ends--> 
	



		
	</div><!--  containerFluid Ends -->


               <script src="js/jquery-1.11.3.min.js"></script> <!-- this works for collapse -->
                <script src="js/bootstrap.min.js"></script>
	
</body>
</html>






